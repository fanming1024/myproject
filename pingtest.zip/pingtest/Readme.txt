Version Control:

Version 1.0 Create the basic function with hyper performance programming tech to support multi-threads and multi-processes. Windows defender virus scan passed  --2021/1/27

Usage:

Create ip.txt under the current folder and put IP address to the file direclty (only IPs), it is recommened to pull the IP list from Excel.
out.txt content can be imported to Excel sheet to support further processing for server sheets.


--Simon Fan
2021/1/27